% this program reads 3D breast data and  creates 2D slices with mesh size
% 2dx,  2dy, 2dz

clear 
close all
%D = niftiread('a01.nii');


load mtype.txt;

D= mtype;

%these sizes are from breastInfo.txt
nx= 316; %  n_x
ny = 352; %  n_y
nz = 307; %  n_z

%sizes of new 2D slice with biggers size mesh
nx_new = nx/2;
ny_new = ny/2;

%Zarray = zeros(nx*ny,1);

% sort the data D into the mesh-grid
 Z = zeros(nx,ny,6);

 
Y  = zeros(nx,ny);
Y1  = zeros(nx,ny);
Y2  = zeros(nx,ny);


hx = 1/(nx-1);
hy = 1/(ny-1);
hz = 1/(nz-1);

hx_new = 2*hx;
hy_new = 2*hy;


xmin=0.0;
ymin = 0.0;
sch = 0;

ii= 0; 
jj = 0;
count = 0;
count4 = 0;
count8 = 0;

for j=1:ny
  for i=1:nx
     % for k= 1:nz
	 % Z(i,j) = D(j+nx*(i-1));
     
     %********** save different slices in 2D ***************
     k= 100;
      sch = sch  +1;
      % for Matlab visualization
     Z(i,j,1) = D(i+nx*((j-1) + ny*(k-1)));
    
     
     
 % to save xy-slice which we want  to use in FEM computations 
 
     Zarray(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
         
     %******************************************************
      k= 112;
     
      %for Matlab visualization
     Z(i,j,2) = D(i+nx*((j-1) + ny*(k-1)));
     
 % to save xy-slice which we want  to use in FEM computations 
     Z1array(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
          
     % for inp file to make computations on the twice bigger mesh
     if rem(i,2) == 0 && rem(j,2) == 0
         count = count +1;
     Z1array2h(count,1) = D(i+nx*((j-1) + ny*(k-1)));   
     end 
     
     % for inp file to make computations on the   fourth times bigger mesh
     if rem(i,4) == 0 && rem(j,4) == 0
         count4 = count4 +1;
     Z1array4h(count4,1) = D(i+nx*((j-1) + ny*(k-1)));   
     end 
     
      % for inp file to make computations on the   8 times bigger mesh
     if rem(i,8) == 0 && rem(j,8) == 0
         count8 = count8 +1;
     Z1array8h(count8,1) = D(i+nx*((j-1) + ny*(k-1)));   
     end 
     %******************************************************
      k= 125;
     
      %for Matlab visualization
     Z(i,j,3) = D(i+nx*((j-1) + ny*(k-1)));
     
 % to save xy-slice which we want  to use in FEM computations 
     Z2array(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
     %******************************************************
      k= 137;
    
      %for Matlab visualization
     Z(i,j,4) = D(i+nx*((j-1) + ny*(k-1)));
     
 % to save xy-slice which we want  to use in FEM computations 
     Z3array(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
        
      %******************************************************
      k= 175;
    
      %for Matlab visualization
     Z(i,j,5) = D(i+nx*((j-1) + ny*(k-1)));
     
 % to save xy-slice which we want  to use in FEM computations 
     Z4array(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
        
      %******************************************************
      k= 187;
      
      %for Matlab visualization
     Z(i,j,6) = D(i+nx*((j-1) + ny*(k-1)));
     
 % to save xy-slice which we want  to use in FEM computations 
     Z5array(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
        
     
  end
end




save('Zarray.dat','Zarray','-ascii');
save('Z1array.dat','Z1array','-ascii');
save('Z2array.dat','Z2array','-ascii');
save('Z3array.dat','Z3array','-ascii');
save('Z4array.dat','Z4array','-ascii');
save('Z5array.dat','Z5array','-ascii');


save('Z1array2h.dat','Z1array2h','-ascii');

save('Z1array4h.dat','Z1array4h','-ascii');

save('Z1array8h.dat','Z1array8h','-ascii');
  
%% plotting
x1=0:hx:1;
y1=0:hy:1;



  for i=1:6
%plot original image 
subplot(3, 2, i)
h = surf(y1,x1,Z(:,:,i))
view(2)
colormap winter
%colormap default

set(h,'edgecolor','none')
  end

