% This program reads 3D breast data located in the files
% mtype.txt and pval.txt
%and  creates   3D data for AFEM
% with different mesh sizes (h, 2h, 4h, 8h)
% Data files  mtype.txt and pval.txt  can be obtained from
% https://uwcem.ece.wisc.edu/MRIdatabase/


clear 
close all
%D = niftiread('a01.nii');


load mtype.txt;
load  pval.txt;


D= mtype;
Pval = pval;

%these sizes are from breastInfo.txt, see more info at
% https://uwcem.ece.wisc.edu/MRIdatabase/InstructionManual.pdf
nx= 316; %  n_x
ny = 352; %  n_y
nz = 307; %  n_z

% mesh sizes of the original mesh
hx = 10/(nx-1);
hy = 10/(ny-1);
hz = 10/(nz-1);


sch = 0;


count = 0;
count4 = 0;
count8 = 0;


 for k= 1:nz  % to save 3D data
for j=1:ny
  for i=1:nx
     % for k= 1:nz  % to save 3D data
	 % Z(i,j) = D(j+nx*(i-1));
     
     %********** save different slices in 2D ***************
    % k= 100;
      sch = sch  +1;
      % for Matlab's visualization
    % Z3D(j,i,k) = D(i+nx*((j-1) + ny*(k-1)));
    
     
     
 % to save xy-slice which we want  to use in FEM computations 
 
%     Zarray(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));

% to save  3D data which we want  to use in FEM computations 
 %uncomment if you want to use it
 
 %     Array3D(sch,1) =  D(i+nx*((j-1) + ny*(k-1)));
      Pval3D(sch,1) =  Pval(i+nx*((j-1) + ny*(k-1)));

     %******************************************************
   
     % for inp file to make computations on the twice bigger mesh
     if rem(i,2) == 0 && rem(j,2) == 0 && rem(k,2) == 0
         count = count +1;

     Array3D2h(count,1) = D(i+nx*((j-1) + ny*(k-1)));
     Pval3D2h(count,1) =  Pval(i+nx*((j-1) + ny*(k-1)));

if (k==150)
% Array3D2hk150(count,1) = D(i+nx*((j-1) + ny*(k-1)));
 Z3D2hk150(j,i) = D(i+nx*((j-1) + ny*(k-1)));
end
end 
     
     % for inp file to make computations on the   fourth times bigger mesh
     if rem(i,4) == 0 && rem(j,4) == 0  && rem(k,4) == 0
         count4 = count4 +1;
     Array3D4h(count4,1) = D(i+nx*((j-1) + ny*(k-1)));
 Pval3D4h(count4,1) =  Pval(i+nx*((j-1) + ny*(k-1)));

if (k==100)
 Array3D4hk100(count4,1) = D(i+nx*((j-1) + ny*(k-1)));
 Z3D4hk100(j,i) = D(i+nx*((j-1) + ny*(k-1)));
end
     end 
     
      % for inp file to make computations on the   8 times bigger mesh
     if rem(i,8) == 0 && rem(j,8) == 0 && rem(k,8) == 0
         count8 = count8 +1;
     Array3D8h(count8,1) = D(i+nx*((j-1) + ny*(k-1)));
     Pval3D8h(count8,1) =  Pval(i+nx*((j-1) + ny*(k-1)));
     end 
     %******************************************************
    
        
     end
  end
end

% saves data for original mesh with mesh size h
% save('Array3D.dat','Array3D','-ascii');
% saves data for twice bigger mesh with mesh size 2h
%save('Array3D2h.dat','Array3D2h','-ascii');
% saves data for 4 times bigger mesh with mesh size 4h 
save('Array3D4h.dat','Array3D4h','-ascii');
% saves data for 8 times bigger mesh with mesh size 8h
save('Array3D8h.dat','Array3D8h','-ascii');
save('Pval3D8h.dat','Pval3D8h','-ascii');
%*******************************************************************

%  3D visualization of function on the mesh with new mesh size h


[XM,YM,ZM, XX, YY, ZZ, nno, Z3D]  = Visualize3D(Pval3D,hx,hy,hz);

 figure
 colormap jet

 subplot(2,2,1);

 slice(XM,YM,ZM,Z3D,XX(150),YY(150),ZZ(150));

 grid('on');
 colorbar
    axis image
    xlabel('x ')
    ylabel('y ')
    zlabel('z')
   title(['Nr.nodes in the original mesh: ',num2str(nno)]);
    shading interp
  
%**********************************************************************
%  3D visualization of function on the mesh with new mesh size 2h


%sizes with bigger size meshes 2h
hx_new =  2*hx;
hy_new =  2*hy;
hz_new =  2*hz;

[XM,YM,ZM, XX, YY, ZZ, nno, Z3D2h]  = Visualize3D(Pval3D2h,hx_new,hy_new,hz_new);

%figure
 colormap jet

subplot(2,2,2);
 slice(XM,YM,ZM,Z3D2h,XX(75),YY(75),ZZ(75));

 grid('on');
 colorbar
    axis image
    xlabel('x ')
    ylabel('y ')
    zlabel('z')
   title(['Nr.nodes in the mesh, h=2h: ',num2str(nno)]);
    shading interp
%***************************************************************************
%  3D visualization of function on the mesh with new mesh size 4h

%sizes with bigger size meshes 4h
hx_new =  4*hx;
hy_new =  4*hy;
hz_new =  4*hz;


[XM,YM,ZM, XX, YY, ZZ, nno, Z3D4h]  = Visualize3D(Pval3D4h,hx_new,hy_new,hz_new);


%figure
colormap jet

subplot(2,2,3);
 slice(XM,YM,ZM,Z3D4h,XX(37),YY(37),ZZ(37));

 colorbar
    axis image
    xlabel('x ')
    ylabel('y ')
    zlabel('z')


   title(['Nr.nodes in the mesh, h =4h: ',num2str(nno)]);
 grid('on');
    shading interp
%*************************************************************************
%  3D visualization of function on the mesh with new mesh size 8h
%*************************************************************************
nx_new = floor(nx/8);
ny_new = floor(ny/8);
nz_new = floor(nz/8);

%sizes with bigger size meshes 8h
hx_new = 10/(nx_new -1)
hy_new = 10/(ny_new -1)
hz_new = 10/(nz_new - 1)



[XM, YM, ZM, XX,YY, ZZ, nno, Z3D8h]  = Visualize3D(Pval3D8h,hx_new,hy_new,hz_new);


%figure
colormap jet
subplot(2,2,4);

 slice(XM,YM,ZM,Z3D8h,XX(19),YY(19),ZZ(19));

 colorbar
    axis image
    xlabel('x ')
    ylabel('y ')
    zlabel('z')


   title(['Nr.nodes in the mesh, h = 8h: ',num2str(nno)]);
 grid('on');
    shading interp


%**************************************************************************
% Function for vizualization of 3D solution in Matlab
%**************************************************************************

   function [XM,YM,ZM, XX, YY, ZZ,nno, Z3D] =  Visualize3D(Array3D,hx,hy,hz)

   
XX = 0:hx:10;
YY = 0:hy:10;
ZZ = 0:hz:10-hz;

  
       
[XM, YM, ZM] = meshgrid(XX, YY, ZZ);

nx = size(XX,2)
ny = size(YY,2)
nz = size(ZZ,2)

  nno = nx*ny*nz

     for kk= 1:nz
  for jj=1:ny
  for ii=1:nx
 % for Matlab's visualization
		globnr = ii+nx*((jj-1) + ny*(kk-1));
   Z3D(jj,ii,kk) = Array3D(globnr);

end
end
end

   end
   
